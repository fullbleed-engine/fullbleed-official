# SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Fullbleed-Commercial
from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())
